// config.js
const config = {
  apiKey: 'VQcKNrZqtluwurOkpho0cIyYqEHnFZkGXhzNqCM0', // set API key
};

module.exports = config;